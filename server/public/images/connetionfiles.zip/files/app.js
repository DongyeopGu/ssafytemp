var express = require('express');

var app = express(); // 소켓통신을 위한 
var http = require('http').createServer(app);
var io = require('socket.io')(http, {
  pingTimeout: 1000
});

require('./libs/socketConnection')(io);

app.listen(3001, () => {
  console.log('NFC를 읽을 준비 완료');
});